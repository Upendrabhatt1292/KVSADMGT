# Setting up Google OAuth Credentials

## Step 1: Create a Google Cloud Project
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Click on the project dropdown at the top of the page
3. Click "New Project"
4. Enter a project name (e.g., "KV Admission System")
5. Click "Create"

## Step 2: Enable OAuth API
1. In the left sidebar, click "APIs & Services" > "Library"
2. Search for "Google OAuth2 API"
3. Click "Enable"

## Step 3: Configure OAuth Consent Screen
1. Go to "APIs & Services" > "OAuth consent screen"
2. Select "External" user type
3. Fill in the required information:
   - App name: "KV Admission System"
   - User support email: Your email address
   - Developer contact information: Your email address
4. Click "Save and Continue"
5. Skip adding scopes, click "Save and Continue"
6. Add your email as a test user
7. Click "Save and Continue"

## Step 4: Create OAuth Credentials
1. Go to "APIs & Services" > "Credentials"
2. Click "Create Credentials" > "OAuth client ID"
3. Choose "Web application" as the application type
4. Name: "KV Admission System Web Client"
5. Under "Authorized redirect URIs", add:
   ```
   https://{your-repl-domain}/oauth2callback
   ```
   (Replace {your-repl-domain} with your actual Replit domain)
6. Click "Create"

## Step 5: Save Your Credentials
After creating the credentials, you'll see a popup with your:
- Client ID (looks like: `123456789-abcdef.apps.googleusercontent.com`)
- Client Secret (a string of random characters)

Keep these values safe - you'll need to add them to your application!
