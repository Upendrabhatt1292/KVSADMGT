from google.oauth2 import id_token
from google.auth.transport import requests
from google_auth_oauthlib.flow import Flow
import os
import json
from models import User, get_db
import streamlit as st

GOOGLE_CLIENT_ID = os.getenv('GOOGLE_CLIENT_ID')
GOOGLE_CLIENT_SECRET = os.getenv('GOOGLE_CLIENT_SECRET')
# Get Replit domain from environment
REPLIT_DOMAIN = os.getenv('REPL_SLUG') + '.' + os.getenv('REPL_OWNER') + '.repl.co'
REDIRECT_URI = f"https://{REPLIT_DOMAIN}/oauth2callback"

def create_google_oauth_flow():
    try:
        if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
            st.error("Google OAuth credentials are not configured. Please set them up in the project settings.")
            return None

        flow = Flow.from_client_config(
            {
                "web": {
                    "client_id": GOOGLE_CLIENT_ID,
                    "client_secret": GOOGLE_CLIENT_SECRET,
                    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                    "token_uri": "https://oauth2.googleapis.com/token",
                    "redirect_uris": [REDIRECT_URI]
                }
            },
            scopes=['openid', 'https://www.googleapis.com/auth/userinfo.email', 'https://www.googleapis.com/auth/userinfo.profile']
        )
        flow.redirect_uri = REDIRECT_URI
        return flow
    except Exception as e:
        st.error(f"Error creating OAuth flow: {str(e)}")
        return None

def verify_google_token(token):
    try:
        idinfo = id_token.verify_oauth2_token(token, requests.Request(), GOOGLE_CLIENT_ID)
        if idinfo['iss'] not in ['accounts.google.com', 'https://accounts.google.com']:
            raise ValueError('Wrong issuer.')
        return idinfo
    except Exception as e:
        st.error(f"Error verifying token: {str(e)}")
        return None

def handle_google_auth(google_user_data, db):
    try:
        email = google_user_data.get('email')
        if not email:
            st.error("No email found in Google user data")
            return None

        user = db.query(User).filter(User.email == email).first()

        if not user:
            # Create new user
            user = User(
                email=email,
                username=email.split('@')[0],  # Use email prefix as username
                google_id=google_user_data.get('sub'),
                is_active=True
            )
            db.add(user)
            db.commit()
            db.refresh(user)

        return user
    except Exception as e:
        st.error(f"Error handling Google auth: {str(e)}")
        return None