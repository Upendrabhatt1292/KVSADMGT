import streamlit as st
import pandas as pd
import base64
from datetime import datetime
import logging
from utils import (
    load_data, save_data, validate_student_data, generate_session_years,
    validate_mobile, generate_otp, is_otp_expired
)
from models import get_db, User
from auth import authenticate_user, create_user, get_password_hash
import re
from sqlalchemy.exc import SQLAlchemyError
import time
import secrets
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
from email_utils import send_password_reset_email
from firebase_config import initialize_firebase

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="KV Admission Management System",
    page_icon="📚",
    layout="wide"
)

# Initialize Firebase
if not initialize_firebase():
    st.error("Failed to initialize Firebase. Some features may not work properly.")

# Initialize session state
if 'data' not in st.session_state:
    st.session_state.data = load_data()
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'auth_page' not in st.session_state:
    st.session_state.auth_page = 'login'
if 'signup_success' not in st.session_state:
    st.session_state.signup_success = False
if 'form_data' not in st.session_state:
    st.session_state.form_data = {}
if 'form_submitted' not in st.session_state:
    st.session_state.form_submitted = False
if 'recovery_page' not in st.session_state:
    st.session_state.recovery_page = False
if 'otp_data' not in st.session_state:
    st.session_state.otp_data = {}
if 'otp_verified' not in st.session_state:
    st.session_state.otp_verified = False

def header_with_logo():
    """Display header with logo"""
    col1, col2 = st.columns([4, 1])
    with col1:
        st.markdown(
            '<h1 class="main-header">Kendriya Vidyalaya Admission Management System</h1>',
            unsafe_allow_html=True
        )
    with col2:
        st.image("attached_assets/images.png", width=100)

def show_admission_form(is_mobile):
    st.markdown("<h2>New Student Admission</h2>", unsafe_allow_html=True)

    # Create class and section options
    class_options = [str(i) for i in range(1, 13)]
    section_options = ['A', 'B', 'C']

    # Initialize or reset form data in session state
    form_keys = ['admission_number', 'student_name', 'father_name', 'mother_name', 
                 'parent_org', 'parent_mobile', 'pen_number']

    if st.session_state.get('form_submitted', False):
        # Show success message and Add More button
        st.success("✅ Student admission data saved successfully!")

        if st.button("➕ Add Another Student", use_container_width=True):
            # Clear form data for new entry
            for key in form_keys:
                if key in st.session_state:
                    del st.session_state[key]
            st.session_state.form_submitted = False
            st.rerun()
        return

    st.markdown('<div class="admission-form">', unsafe_allow_html=True)

    # Session selection at the top
    session = st.selectbox("Session", generate_session_years(), 
        key="session_input",
        index=0)

    if is_mobile:
        # Single column layout for mobile
        admission_number = st.text_input("Admission Number", key="admission_number")
        student_name = st.text_input("Student Name", key="student_name")

        # Separate class and section
        selected_class = st.selectbox("Class", class_options, key="class")
        selected_section = st.selectbox("Section", section_options, key="section")
        gender = st.selectbox("Gender", ["Male", "Female", "Other"])

        st.markdown('<div class="form-section">', unsafe_allow_html=True)
        admission_category = st.selectbox("Admission Category", 
            ["CATEGORY 1", "CATEGORY 2", "CATEGORY 3", "CATEGORY 4", "CATEGORY 5", "CATEGORY 6"])
        social_category = st.selectbox("Social Category", 
            ["General", "OBC", "SC", "ST", "EWS"])

        col1, col2 = st.columns(2)
        with col1:
            is_rte = st.selectbox("RTE", ["NO", "YES"])
        with col2:
            is_bpl = st.selectbox("BPL", ["NO", "YES"])
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="form-section">', unsafe_allow_html=True)
        father_name = st.text_input("Father's Name", key="father_name")
        mother_name = st.text_input("Mother's Name", key="mother_name")
        parent_org = st.text_input("Parent's Job Organisation", key="parent_org")
        parent_mobile = st.text_input("Parent's Mobile Number", key="parent_mobile")
        pen_number = st.text_input("PEN Number", key="pen_number")
        admission_type = st.selectbox("Admission Type", 
            ["Fresh", "KV Transfer Certificate", "APS"])
        st.markdown('</div>', unsafe_allow_html=True)
    else:
        # Desktop layout
        col1, col2, col3 = st.columns(3)
        with col1:
            admission_number = st.text_input("Admission Number", key="admission_number")
            student_name = st.text_input("Student Name", key="student_name")
            selected_class = st.selectbox("Class", class_options, key="class")
            selected_section = st.selectbox("Section", section_options, key="section")
            gender = st.selectbox("Gender", ["Male", "Female", "Other"])

        with col2:
            admission_category = st.selectbox("Admission Category", 
                ["CATEGORY 1", "CATEGORY 2", "CATEGORY 3", "CATEGORY 4", "CATEGORY 5", "CATEGORY 6"])
            social_category = st.selectbox("Social Category", 
                ["General", "OBC", "SC", "ST", "EWS"])
            is_rte = st.selectbox("RTE", ["NO", "YES"])
            is_bpl = st.selectbox("BPL", ["NO", "YES"])

        with col3:
            father_name = st.text_input("Father's Name", key="father_name")
            mother_name = st.text_input("Mother's Name", key="mother_name")
            parent_org = st.text_input("Parent's Job Organisation", key="parent_org")
            parent_mobile = st.text_input("Parent's Mobile Number", key="parent_mobile")
            pen_number = st.text_input("PEN Number", key="pen_number")
            admission_type = st.selectbox("Admission Type", 
                ["Fresh", "KV Transfer Certificate", "APS"])

    st.markdown('</div>', unsafe_allow_html=True)

    # Submit button
    if st.button("Submit", use_container_width=True):
        # Create student data dictionary
        student_data = {
            'session': session,
            'admission_number': admission_number,
            'student_name': student_name,
            'class_section': f"{selected_class}-{selected_section}",
            'gender': gender,
            'admission_category': admission_category,
            'social_category': social_category,
            'father_name': father_name,
            'mother_name': mother_name,
            'parent_org': parent_org,
            'parent_mobile': parent_mobile,
            'admission_type': admission_type,
            'is_rte': is_rte,
            'is_bpl': is_bpl,
            'pen_number': pen_number
        }

        # Validate the data
        is_valid, message = validate_student_data(student_data)

        if is_valid:
            # Save the data
            st.session_state.data = save_data(student_data, st.session_state.data)
            st.session_state.form_submitted = True
            st.rerun()  # This will trigger a rerun to clear the form
        else:
            st.error(message)

def show_records(is_mobile):
    st.markdown("<h2>View/Search Records</h2>", unsafe_allow_html=True)

    if st.session_state.data.empty:
        st.warning("No records found in the database.")
        return

    # Add filters based on multiple criteria
    if is_mobile:
        search_term = st.text_input("Search by Name/Admission Number")
        class_filter = st.selectbox("Filter by Class", 
            ["All"] + list(st.session_state.data['class_section'].unique()))
        admission_category_filter = st.selectbox("Filter by Admission Category",
            ["All"] + list(st.session_state.data['admission_category'].unique()))
        social_category_filter = st.selectbox("Filter by Social Category",
            ["All"] + list(st.session_state.data['social_category'].unique()))
        gender_filter = st.selectbox("Filter by Gender",
            ["All"] + list(st.session_state.data['gender'].unique()))
        admission_type_filter = st.selectbox("Filter by Admission Type",
            ["All"] + list(st.session_state.data['admission_type'].unique()))
    else:
        col1, col2, col3 = st.columns(3)
        with col1:
            search_term = st.text_input("Search by Name/Admission Number")
            class_filter = st.selectbox("Filter by Class", 
                ["All"] + list(st.session_state.data['class_section'].unique()))
        with col2:
            admission_category_filter = st.selectbox("Filter by Admission Category",
                ["All"] + list(st.session_state.data['admission_category'].unique()))
            social_category_filter = st.selectbox("Filter by Social Category",
                ["All"] + list(st.session_state.data['social_category'].unique()))
        with col3:
            gender_filter = st.selectbox("Filter by Gender",
                ["All"] + list(st.session_state.data['gender'].unique()))
            admission_type_filter = st.selectbox("Filter by Admission Type",
                ["All"] + list(st.session_state.data['admission_type'].unique()))

    # Apply filters
    df = st.session_state.data.copy()
    if search_term:
        df = df[
            df['student_name'].str.contains(search_term, case=False) |
            df['admission_number'].str.contains(search_term, case=False)
        ]
    if class_filter != "All":
        df = df[df['class_section'] == class_filter]
    if admission_category_filter != "All":
        df = df[df['admission_category'] == admission_category_filter]
    if social_category_filter != "All":
        df = df[df['social_category'] == social_category_filter]
    if gender_filter != "All":
        df = df[df['gender'] == gender_filter]
    if admission_type_filter != "All":
        df = df[df['admission_type'] == admission_type_filter]

    # Add serial number
    if not df.empty:
        df = df.reset_index(drop=True)
        df.index = df.index + 1
        df = df.rename_axis('SL No')

    # Wrap table in scrollable container for mobile
    st.markdown('<div class="table-scroll-wrapper">', unsafe_allow_html=True)
    st.dataframe(df, use_container_width=True)
    st.markdown('</div>', unsafe_allow_html=True)

    # Show record count
    st.info(f"Showing {len(df)} records")

def validate_email(email):
    """Validate email format."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))

def validate_password(password):
    """Validate password strength."""
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    if not any(c.isupper() for c in password):
        return False, "Password must contain at least one uppercase letter"
    if not any(c.islower() for c in password):
        return False, "Password must contain at least one lowercase letter"
    if not any(c.isdigit() for c in password):
        return False, "Password must contain at least one number"
    return True, "Password is valid"

def signup_page():
    header_with_logo()
    st.markdown("<h2>Create Account</h2>", unsafe_allow_html=True)

    with st.container():
        st.markdown('<div class="auth-form">', unsafe_allow_html=True)

        username = st.text_input("Username", key="signup_username")
        email = st.text_input("Email", key="signup_email")
        password = st.text_input("Password", type="password", key="signup_password")
        confirm_password = st.text_input("Confirm Password", type="password", key="confirm_password")

        if st.button("Create Account", use_container_width=True):
            if not all([username, email, password]):
                st.error("All fields are required")
                return

            if not validate_email(email):
                st.error("Please enter a valid email address")
                return

            is_valid_password, password_message = validate_password(password)
            if not is_valid_password:
                st.error(password_message)
                return

            if password != confirm_password:
                st.error("Passwords do not match")
                return

            try:
                db = next(get_db())
                try:
                    create_user(db, username, email, password)
                    st.success("✅ Account created successfully! Please log in.")
                    st.session_state.signup_success = True
                    time.sleep(2)  # Give user time to see the success message
                    st.session_state.auth_page = 'login'
                    st.rerun()
                except SQLAlchemyError as e:
                    if "unique constraint" in str(e).lower():
                        st.error("Username or email already exists")
                    else:
                        st.error(f"Database error: {str(e)}")
                finally:
                    db.close()
            except Exception as e:
                st.error(f"Connection error: {str(e)}")

        if st.button("Already have an account? Log in", use_container_width=True):
            st.session_state.auth_page = 'login'
            st.rerun()

        st.markdown('</div>', unsafe_allow_html=True)

def generate_reset_token():
    """Generate a secure reset token."""
    return secrets.token_urlsafe(32)

def create_reset_token(email):
    """Creates a reset token and stores it in the database (replace with your actual DB interaction)."""
    token = generate_reset_token()
    # Add your database logic here to store the token associated with the email
    # Example (assuming you have a way to update user data):
    try:
        db = next(get_db())
        user = db.query(User).filter(User.email == email).first()
        if user:
            user.reset_token = token
            db.commit()
            return token
        else:
            return None
    except Exception as e:
        logger.error(f"Error creating reset token: {e}")
        return None
    finally:
        db.close() if db else None

def send_reset_email(email, reset_token):
    """Sends a password reset email."""
    try:
        if send_password_reset_email(email, reset_token):
            logger.info(f"Reset email sent successfully to {email}")
            return True
        return False
    except Exception as e:
        logger.error(f"Failed to send reset email: {str(e)}")
        return False



def reset_password(db, email, new_password):
    """Resets the user's password in the database."""
    try:
        user = db.query(User).filter(User.email == email).first()
        if user:
            from auth import get_password_hash
            user.hashed_password = get_password_hash(new_password)
            db.commit()
            return True
        return False
    except Exception as e:
        logger.error(f"Error resetting password: {e}")
        db.rollback()
        return False

def show_recovery_page():
    """Handle account recovery with email reset."""
    header_with_logo()
    st.markdown('<div class="auth-form">', unsafe_allow_html=True)
    st.markdown("<h2>Account Recovery</h2>", unsafe_allow_html=True)

    email = st.text_input("Enter your registered email address")
    if st.button("Send Reset Link", use_container_width=True):
        if email and validate_email(email):
            try:
                db = next(get_db())
                user = db.query(User).filter(User.email == email).first()
                if user:
                    reset_token = create_reset_token(email)
                    if send_reset_email(email, reset_token):
                        st.success("✅ Password reset link has been sent to your email.")
                        st.info("Please check your email and follow the instructions to reset your password.")
                    else:
                        st.error("Failed to send reset email. Please try again later.")
                else:
                    st.error("No account found with this email address")
            except Exception as e:
                logger.error(f"Error sending reset email: {str(e)}")
                st.error("An error occurred. Please try again later.")
        else:
            st.error("Please enter a valid email address")

    if st.button("Back to Login", use_container_width=True):
        st.session_state.recovery_page = False
        st.session_state.auth_page = 'login'
        st.rerun()

    st.markdown('</div>', unsafe_allow_html=True)

def login_page():
    header_with_logo()

    with st.container():
        st.markdown('<div class="auth-form">', unsafe_allow_html=True)
        st.markdown("<h2>Login</h2>", unsafe_allow_html=True)

        # Show success message if coming from signup
        if st.session_state.signup_success:
            st.success("✅ Account created successfully! Please log in.")
            st.session_state.signup_success = False  # Reset the flag

        username_or_email = st.text_input("Username or Email")
        password = st.text_input("Password", type="password")

        col1, col2 = st.columns(2)

        with col1:
            if st.button("Login", use_container_width=True):
                try:
                    db = next(get_db())
                    try:
                        user = authenticate_user(db, username_or_email, password)
                        if user:
                            st.session_state.logged_in = True
                            st.session_state.current_user = user
                            st.rerun()
                        else:
                            st.info("Please check your username/email and password and try again")
                    except SQLAlchemyError as e:
                        st.error(f"Database error: {str(e)}")
                    finally:
                        db.close()
                except Exception as e:
                    st.error(f"Connection error: {str(e)}")

        with col2:
            if st.button("Forgot Password/Username?", use_container_width=True):
                st.session_state.recovery_page = True
                st.rerun()

        if st.button("Don't have an account? Sign up", use_container_width=True):
            st.session_state.auth_page = 'signup'
            st.rerun()

        st.markdown('</div>', unsafe_allow_html=True)

def main():
    if not st.session_state.logged_in:
        if st.session_state.recovery_page:
            show_recovery_page()
        elif st.session_state.auth_page == 'login':
            login_page()
        else:
            signup_page()
        return

    header_with_logo()
    # Detect mobile view
    is_mobile = st.checkbox("Mobile View", value=st.session_state.get('mobile_view', False), key='mobile_view')

    # Logout button
    if st.sidebar.button("Logout", use_container_width=True):
        st.session_state.logged_in = False
        st.session_state.current_user = None
        st.rerun()

    # Sidebar navigation
    page = st.sidebar.radio("Navigation", ["Add New Admission", "View/Search Records", "Export Data"])

    if page == "Add New Admission":
        show_admission_form(is_mobile)
    elif page == "View/Search Records":
        show_records(is_mobile)
    else:
        export_data()

def export_data():
    st.markdown("<h2>Export Data</h2>", unsafe_allow_html=True)

    if st.session_state.data.empty:
        st.warning("No data available to export.")
        return

    csv = st.session_state.data.to_csv(index=False)
    b64 = base64.b64encode(csv.encode()).decode()
    href = f'<a href="data:file/csv;base64,{b64}" download="student_records.csv" class="download-button">Download CSV File</a>'
    st.markdown(href, unsafe_allow_html=True)

if __name__ == "__main__":
    main()