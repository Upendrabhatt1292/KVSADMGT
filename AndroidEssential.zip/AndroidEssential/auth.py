import bcrypt
import jwt
from datetime import datetime, timedelta
from models import User
from sqlalchemy.orm import Session
from sqlalchemy import or_
import logging
import secrets

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

SECRET_KEY = "your-secret-key-here"  # In production, use environment variable
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
RESET_TOKEN_EXPIRE_MINUTES = 30

def get_password_hash(password: str) -> str:
    """Hash a password for storing."""
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a stored password against one provided by user."""
    try:
        return bcrypt.checkpw(plain_password.encode(), hashed_password.encode())
    except Exception as e:
        logger.error(f"Password verification error: {str(e)}")
        return False

def create_access_token(data: dict):
    """Create a new access token."""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def create_reset_token(email: str) -> str:
    """Create a password reset token."""
    expire = datetime.utcnow() + timedelta(minutes=RESET_TOKEN_EXPIRE_MINUTES)
    token_data = {
        "sub": email,
        "exp": expire,
        "type": "reset"
    }
    return jwt.encode(token_data, SECRET_KEY, algorithm=ALGORITHM)

def verify_reset_token(token: str) -> str:
    """Verify a password reset token and return the email if valid."""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        if payload.get("type") != "reset":
            return None
        return payload.get("sub")
    except jwt.ExpiredSignatureError:
        logger.error("Reset token has expired")
        return None
    except jwt.JWTError as e:
        logger.error(f"Invalid reset token: {str(e)}")
        return None

def reset_password(db: Session, email: str, new_password: str) -> bool:
    """Reset user's password."""
    try:
        user = db.query(User).filter(User.email == email).first()
        if not user:
            return False
        user.hashed_password = get_password_hash(new_password)
        db.commit()
        return True
    except Exception as e:
        logger.error(f"Password reset error: {str(e)}")
        db.rollback()
        return False

def authenticate_user(db: Session, username_or_email: str, password: str):
    """Authenticate a user using either username or email."""
    try:
        logger.info(f"Authentication attempt for user: {username_or_email}")
        user = db.query(User).filter(
            or_(
                User.username == username_or_email,
                User.email == username_or_email
            )
        ).first()

        if not user:
            logger.info(f"User not found: {username_or_email}")
            return None

        if not verify_password(password, user.hashed_password):
            logger.info(f"Invalid password for user: {username_or_email}")
            return None

        logger.info(f"Successful authentication for user: {username_or_email}")
        return user
    except Exception as e:
        logger.error(f"Authentication error: {str(e)}")
        return None

def create_user(db: Session, username: str, email: str, password: str):
    """Create a new user."""
    try:
        hashed_password = get_password_hash(password)
        user = User(
            username=username,
            email=email,
            hashed_password=hashed_password,
            is_active=True
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        logger.info(f"Successfully created user: {username}")
        return user
    except Exception as e:
        db.rollback()
        logger.error(f"Error creating user: {str(e)}")
        raise e

def create_subscription(db: Session, user: User):
    user.subscription_end = datetime.utcnow() + timedelta(days=365)
    db.commit()
    return user

def is_subscription_valid(user: User):
    if not user.subscription_end:
        return False
    return user.subscription_end > datetime.utcnow()

def update_device_id(db: Session, user: User, device_id: str):
    user.device_id = device_id
    db.commit()