import smtplib
import random
import logging
import os
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr, formatdate, make_msgid

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def send_password_reset_email(receiver_email: str, reset_token: str) -> bool:
    """
    Send password reset email with reset link.
    Returns success status as boolean.
    """
    max_retries = 3
    retry_delay = 2

    for attempt in range(max_retries):
        try:
            # Hard-code the credentials temporarily to test
            sender_email = "upendra.bhatt12@gmail.com"
            app_password = "hnvr krrh hces xyoj"

            # Create message
            msg = MIMEMultipart('alternative')
            msg["From"] = formataddr(("KV Admission System", sender_email))
            msg["To"] = receiver_email
            msg["Subject"] = "[KV Admission] Password Reset Request"
            msg["Date"] = formatdate(localtime=True)
            msg["Message-ID"] = make_msgid(domain='gmail.com')
            msg["X-Priority"] = "1"  # High priority
            msg["X-MSMail-Priority"] = "High"
            msg["Importance"] = "High"

            # Get Replit domain from REPLIT_DOMAIN environment variable
            replit_domain = os.getenv('REPLIT_DOMAIN', 'localhost:5000')
            reset_link = f"https://{replit_domain}/reset_password?token={reset_token}"

            # Create plain text version
            text_content = f"""
Important: Password Reset Request for KV Admission System

You recently requested to reset your password. Click the link below to proceed:

{reset_link}

This link will expire in 30 minutes.
If you didn't request this reset, please ignore this email.

Best regards,
KV Admission System Team
            """

            # Create HTML version
            html_content = f"""
            <!DOCTYPE html>
            <html>
              <head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
                <title>Reset Your Password</title>
              </head>
              <body style="font-family: Arial, sans-serif; line-height: 1.6; margin: 0; padding: 20px; background-color: #f4f4f4;">
                <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 10px; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                  <h2 style="color: #1f4068; margin-bottom: 20px; text-align: center;">Password Reset Request</h2>
                  <p>Dear User,</p>
                  <p>We received a request to reset your password for your KV Admission System account.</p>
                  <div style="text-align: center; margin: 30px 0;">
                    <a href="{reset_link}" style="background: #1f4068; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">Reset Your Password</a>
                  </div>
                  <p style="color: #666666; font-size: 14px;">This link will expire in 30 minutes for security reasons.</p>
                  <p style="color: #666666; font-size: 14px;">If you didn't request this reset, you can safely ignore this email.</p>
                  <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
                  <p style="color: #666666; font-size: 14px; text-align: center; margin-bottom: 0;">Best regards,<br>KV Admission System Team</p>
                </div>
              </body>
            </html>
            """

            # Attach both versions
            part1 = MIMEText(text_content, 'plain')
            part2 = MIMEText(html_content, 'html')
            msg.attach(part1)
            msg.attach(part2)

            # Create SMTP session for sending the mail
            with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
                logger.info(f"Attempt {attempt + 1}: Authenticating with Gmail SMTP")
                server.login(sender_email, app_password)
                logger.info(f"Sending email to {receiver_email}")
                server.send_message(msg)
                logger.info(f"Reset email sent successfully to {receiver_email}")
                return True

        except smtplib.SMTPAuthenticationError as auth_error:
            logger.error(f"Gmail authentication failed on attempt {attempt + 1}: {str(auth_error)}")
            if attempt == max_retries - 1:
                return False
        except Exception as e:
            logger.error(f"Error during email sending on attempt {attempt + 1}: {str(e)}")
            if attempt == max_retries - 1:
                return False

        # Exponential backoff
        wait_time = retry_delay * (2 ** attempt)
        logger.info(f"Waiting {wait_time} seconds before retry...")
        time.sleep(wait_time)

    return False

def generate_otp():
    """Generate a 6-digit OTP."""
    return str(random.randint(100000, 999999))

def send_otp_email(receiver_email: str, otp: str = None) -> tuple[bool, str]:
    """
    Send OTP to the specified email address.
    If no OTP is provided, generates a new one.
    Returns tuple (success: bool, otp: str)
    """
    try:
        if not otp:
            otp = generate_otp()

        # Hard-code the credentials temporarily to test
        sender_email = "upendra.bhatt12@gmail.com"
        app_password = "hnvr krrh hces xyoj"

        # Create message
        msg = MIMEMultipart('alternative')
        msg["From"] = formataddr(("KV Admission System", sender_email))
        msg["To"] = receiver_email
        msg["Subject"] = "One-Time Password - KV Admission System"
        msg["Date"] = formatdate(localtime=True)
        msg["Message-ID"] = f"<{random.getrandbits(32)}@gmail.com>"

        # Create plain text version
        text_content = f"""
Your One-Time Password (OTP) for KV Admission System

Your OTP is: {otp}

This OTP will expire in 5 minutes.

If you did not request this OTP, please ignore this email.

Best regards,
KV Admission System Team
        """

        # Create HTML version
        html_content = f"""
        <!DOCTYPE html>
        <html>
          <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
          </head>
          <body style="font-family: Arial, sans-serif; line-height: 1.6; margin: 0; padding: 20px;">
            <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 10px; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
              <h2 style="color: #1f4068; margin-bottom: 20px;">One-Time Password (OTP)</h2>
              <p>Your OTP for KV Admission System is:</p>
              <p style="font-size: 32px; font-weight: bold; color: #1f4068; text-align: center; margin: 30px 0;">{otp}</p>
              <p style="color: #666666; font-size: 14px;">This OTP will expire in 5 minutes.</p>
              <p style="color: #666666; font-size: 14px;">If you did not request this OTP, please ignore this email.</p>
              <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
              <p style="color: #666666; font-size: 14px; margin-bottom: 0;">Best regards,<br>KV Admission System Team</p>
            </div>
          </body>
        </html>
        """

        # Attach both versions
        part1 = MIMEText(text_content, 'plain')
        part2 = MIMEText(html_content, 'html')
        msg.attach(part1)
        msg.attach(part2)

        # Create SMTP session for sending the mail
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            logger.info(f"Attempting to authenticate with Gmail SMTP using sender: {sender_email}")
            try:
                server.login(sender_email, app_password)
                server.send_message(msg)
                logger.info(f"OTP sent successfully to {receiver_email}")
                return True, otp
            except smtplib.SMTPAuthenticationError as auth_error:
                logger.error(f"Gmail authentication failed: {str(auth_error)}")
                return False, None
            except Exception as e:
                logger.error(f"Error during email sending: {str(e)}")
                return False, None

    except Exception as e:
        logger.error(f"Failed to send OTP email: {str(e)}")
        return False, None