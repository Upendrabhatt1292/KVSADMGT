import re
import pandas as pd
from typing import Dict, Any, List
import random
import time

def validate_mobile(mobile: str) -> bool:
    """Validate mobile number format."""
    pattern = r"^[6-9]\d{9}$"
    return bool(re.match(pattern, mobile))

def generate_session_years() -> List[str]:
    """Generate list of session years from 2025-26 to 2099-2100."""
    sessions = []
    for year in range(2025, 2100):
        session = f"{year}-{str(year+1)[-2:]}"
        sessions.append(session)
    return sessions

def load_data() -> pd.DataFrame:
    """Load student data from CSV file."""
    try:
        return pd.read_csv("data/students.csv")
    except FileNotFoundError:
        return pd.DataFrame()

def save_data(data: Dict[str, Any], df: pd.DataFrame) -> pd.DataFrame:
    """Save new student data to CSV file."""
    new_df = pd.DataFrame([data])
    if df.empty:
        df = new_df
    else:
        df = pd.concat([df, new_df], ignore_index=True)
    df.to_csv("data/students.csv", index=False)
    return df

def validate_student_data(data: Dict[str, Any]) -> tuple[bool, str]:
    """Validate all student data fields."""
    if not data or not isinstance(data, dict):
        return False, "Invalid data format"

    if 'session' not in data or not data['session']:
        return False, "Please select a session"

    if not data['parent_mobile']:
        return False, "Parent's mobile number is required"

    if not validate_mobile(data['parent_mobile']):
        return False, "Invalid mobile number. Enter 10 digits starting with 6-9."

    required_fields = ['student_name', 'class_section', 'father_name', 'mother_name']
    for field in required_fields:
        if field not in data or not data[field] or not str(data[field]).strip():
            return False, f"{field.replace('_', ' ').title()} is required."

    return True, "All validations passed."

def generate_otp() -> str:
    """Generate a 6-digit OTP."""
    return str(random.randint(100000, 999999))

def is_otp_expired(generated_time: float, expiry_minutes: int = 5) -> bool:
    """Check if OTP has expired."""
    return time.time() - generated_time > (expiry_minutes * 60)