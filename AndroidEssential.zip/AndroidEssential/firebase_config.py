import firebase_admin
from firebase_admin import credentials, db
import os
import logging
import time

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_firebase_connection():
    """Test Firebase connection and database access."""
    try:
        if not firebase_admin._apps:
            initialize_firebase()

        # Try to read from a test location
        ref = db.reference('/test')
        ref.set({'timestamp': time.time()})
        ref.delete()  # Clean up test data
        logger.info("Firebase connection test successful")
        return True
    except Exception as e:
        logger.error(f"Firebase connection test failed: {str(e)}")
        return False

def initialize_firebase():
    """Initialize Firebase Admin SDK"""
    try:
        # Check if already initialized
        if not firebase_admin._apps:
            # Initialize Firebase Admin with service account
            cred = credentials.Certificate({
                "type": "service_account",
                "project_id": os.getenv('FIREBASE_PROJECT_ID'),
                "private_key_id": os.getenv('FIREBASE_PRIVATE_KEY_ID'),
                "private_key": os.getenv('FIREBASE_PRIVATE_KEY').replace('\\n', '\n'),
                "client_email": os.getenv('FIREBASE_CLIENT_EMAIL'),
                "client_id": os.getenv('FIREBASE_CLIENT_ID'),
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
                "client_x509_cert_url": os.getenv('FIREBASE_CLIENT_CERT_URL')
            })
            firebase_admin.initialize_app(cred, {
                'databaseURL': os.getenv('FIREBASE_DATABASE_URL')
            })
            logger.info("Firebase Admin SDK initialized successfully")
            return test_firebase_connection()
        return True
    except Exception as e:
        logger.error(f"Failed to initialize Firebase: {str(e)}")
        return False

def get_database_reference(path):
    """Get a reference to a specific path in the Firebase Realtime Database"""
    try:
        return db.reference(path)
    except Exception as e:
        logger.error(f"Error getting database reference: {str(e)}")
        return None